#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <ws2tcpip.h>

#define PORT 8080

int main() 
{
    WSADATA wsa;
    SOCKET server_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    char buffer[1024];
    int length = sizeof(client_addr);

    char frames[5][6] = {"abcde", "fghij", "klmno", "parst", "uvwxy"};

    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) 
    {
        printf("Windows socket subsystem could not be initialized. Error Code: %d\n", WSAGetLastError());
        return 1;
    }

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == INVALID_SOCKET) 
    {
        printf("Cannot create socket. Error Code: %d\n", WSAGetLastError());
        WSACleanup();
        return 1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    int status = bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr));
    if (status == SOCKET_ERROR) 
    {
        printf("Cannot bind socket. Error Code: %d\n", WSAGetLastError());
        closesocket(server_fd);
        WSACleanup();
        return 1;
    }

    status = listen(server_fd, 3);
    if (status == SOCKET_ERROR) 
    {
        printf("Cannot listen on socket. Error Code: %d\n", WSAGetLastError());
        closesocket(server_fd);
        WSACleanup();
        return 1;
    }

    printf("Server is listening on port %d...\n", PORT);

    status = (client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &length));
    if (status == INVALID_SOCKET) 
    {
        printf("Cannot accept connection. Error Code: %d\n", WSAGetLastError());
        closesocket(server_fd);
        WSACleanup();
        return 1;
    }

    printf("Connection accepted.\n");

    int frame_index = 0;
    char response[10];

    while (1) 
    {
        memset(buffer, 0, 1024);
        int recv_len = recv(client_fd, buffer, 1024, 0);

        if (recv_len == SOCKET_ERROR) 
        {
            printf("Error: recv failed. Error Code: %d\n", WSAGetLastError());
            break;
        } 
        else if (recv_len == 0) 
        {
            printf("Client disconnected.\n");
            break;
        }

        buffer[recv_len] = '\0';

        if (strcmp(frames[frame_index], buffer) == 0) 
        {
            printf("Frame %d: %s\n", frame_index, frames[frame_index]);
            snprintf(response, sizeof(response), "+%d", frame_index);
            send(client_fd, response, strlen(response), 0);
        } 
        else 
        {
            printf("Frame %d is erroneous.\n", frame_index);
            snprintf(response, sizeof(response), "-%d", frame_index);
            send(client_fd, response, strlen(response), 0);
        }

        frame_index++;
        if (frame_index >= 5) 
        {
            frame_index = 0;
        }
    }

    closesocket(client_fd);
    closesocket(server_fd);
    WSACleanup();

    return 0;
}
