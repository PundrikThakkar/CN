#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <time.h>

#define SERVER_IP "127.0.2.1"
#define PORT 8080
#define MSG_SIZE 5

int main() 
{
    WSADATA wsa;
    SOCKET s;
    struct sockaddr_in server;
    char message[MSG_SIZE];
    char server_reply[MSG_SIZE];

    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) 
    {
        printf("Windows socket cannot be initialized. Error: %d\n", WSAGetLastError());
        return 1;
    }

    if ((s = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) {
        printf("Cannot create socket. Error Code: %d\n", WSAGetLastError());
        WSACleanup();
        return 1;
    }

    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr(SERVER_IP);
    server.sin_port = htons(PORT);

    if (connect(s, (struct sockaddr *)&server, sizeof(server)) == SOCKET_ERROR) {
        printf("Cannot connect to server. Error Code: %d\n", WSAGetLastError());
        closesocket(s);
        WSACleanup();
        return 1;
    }

    printf("Server Connected.\n");

    FILE *fp = fopen("practical_4_data.txt", "r");
    if (fp == NULL) 
    {
        printf("Cannot open file.\n");
        closesocket(s);
        WSACleanup();
        return 1;
    }

    int frame_count = 0;

    while (fgets(message, MSG_SIZE + 1, fp) != NULL) 
    {
        message[strcspn(message, "\n")] = 0;

        if (send(s, message, strlen(message), 0) < 0) 
        {
            printf("Error: Send failed. Error Code: %d\n", WSAGetLastError());
            break;
        }

        int recv_len = recv(s, server_reply, MSG_SIZE, 0);
        if (recv_len == SOCKET_ERROR) 
        {
            printf("Error: recv failed. Error Code: %d\n", WSAGetLastError());
            break;
        }

        server_reply[recv_len] = '\0';
        printf("Server reply for frame %d: %s\n", frame_count, server_reply);

        frame_count++;
        Sleep(3000);
    }

    fclose(fp);
    closesocket(s);
    WSACleanup();

    return 0;
}
