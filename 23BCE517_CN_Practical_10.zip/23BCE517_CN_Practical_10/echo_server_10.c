#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>

#define BUFFER_SIZE 1024
#define NUM_PORTS 2

int ports[NUM_PORTS] = {8080, 8081};

DWORD WINAPI handle_client(LPVOID client_socket) {
    SOCKET client_fd = *(SOCKET *)client_socket;
    free(client_socket);

    char buffer[BUFFER_SIZE];
    FILE *file = fopen("received_file.txt", "ab");
    if (file == NULL) {
        printf("Error: Could not open file.\n");
        closesocket(client_fd);
        return 1;
    }

    int bytes_received;
    while ((bytes_received = recv(client_fd, buffer, BUFFER_SIZE, 0)) > 0) {
        fwrite(buffer, 1, bytes_received, file);
    }

    printf("File received from client.\n");
    fclose(file);
    closesocket(client_fd);
    return 0;
}

DWORD WINAPI port_listener(LPVOID port_number) {
    int port = *(int *)port_number;
    SOCKET server_fd, *client_fd;
    struct sockaddr_in server_addr, client_addr;
    int addr_len = sizeof(client_addr);

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == INVALID_SOCKET) {
        printf("Error: Could not create socket on port %d. Error Code: %d\n", port, WSAGetLastError());
        return 1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);

    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
        printf("Error: Could not bind socket on port %d. Error Code: %d\n", port, WSAGetLastError());
        closesocket(server_fd);
        return 1;
    }

    listen(server_fd, 3);
    printf("Server listening on port %d...\n", port);

    while ((client_fd = malloc(sizeof(SOCKET)),
            *client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &addr_len)) != INVALID_SOCKET) {
        printf("Client connected on port %d.\n", port);

        HANDLE client_thread = CreateThread(NULL, 0, handle_client, client_fd, 0, NULL);
        if (client_thread != NULL) {
            CloseHandle(client_thread);
        } else {
            printf("Error creating client thread.\n");
            free(client_fd);
        }
    }

    closesocket(server_fd);
    return 0;
}

int main() {
    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);

    HANDLE port_threads[NUM_PORTS];
    for (int i = 0; i < NUM_PORTS; i++) {
        int *port_number = malloc(sizeof(int));
        *port_number = ports[i];
        port_threads[i] = CreateThread(NULL, 0, port_listener, port_number, 0, NULL);
    }

    WaitForMultipleObjects(NUM_PORTS, port_threads, TRUE, INFINITE);

    WSACleanup();
    return 0;
}
